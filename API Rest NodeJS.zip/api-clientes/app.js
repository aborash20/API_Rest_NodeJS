const express = require('express');
const bodyParser = require('body-parser');
const clientesRoutes = require('./routes/clientesRoutes');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use('/clientes', clientesRoutes);

app.listen(port, () => {
  console.log(`Servidor escuchando en el puerto ${port}`);
});
